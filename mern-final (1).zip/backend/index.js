const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const Product = require("./models/Product");

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect("mongodb+srv://friendly89018_db_user:Aayush1010@cluster0.jgft0ab.mongodb.net/mernDB")
.then(() => console.log("MongoDB Connected"))
.catch(err => console.log(err));

app.get("/api/products", async (req, res) => {
  const products = await Product.find();
  res.json(products);
});

app.get("/add", async (req, res) => {
  await Product.create([
    { name: "Laptop", price: 50000 },
    { name: "Phone", price: 20000 }
  ]);
  res.send("Data Added");
});

app.listen(5000, () => {
  console.log("Server running on port 5000");
});
